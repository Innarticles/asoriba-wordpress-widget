------------------
Free PNG Credit Card, Debit Card and Payment Icons
Designed by Phil Mathews from www.thewebdesignblog.co.uk and released exclusively for Smashing Magazine and its readers.
------------------

This icon pack includes 18 high quality payment icons in PNG format.

These icons are released free of charge and can be used without credit. The icons cannot be resold in any way. The copyright of each logo is owned by the respective payment company and I do not take responsibility for any part of the design of these. They are inteded for you to show what types of payment your website accepts.

Each icon comes in curved and straight edge variations and in 128, 64 and 32 pixel height variations (so you can mix and match the types of payment you accept easily). The icons have been designed by The Web Design Blog as a free download for Smashing Magazine's readers.

Link: http://www.thewebdesignblog.co.uk

Thanks for downloading :-)

--------------------------------------------

Dear friends,

thank you for downloading this file.

This freebie has been brought to you by SmashingMagazine.com.
You can freely use it for both your private and commercial projects, including software, online services, templates and themes.
The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use. The icons may not be offered for free downloading from websites
other than SmashingMagazine.com.
Please link to the article in which this freebie was released if you would like to spread the word.

Smashing Magazine Team,
www.smashingmagazine.com
